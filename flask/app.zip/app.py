from flask import Flask, url_for, render_template, send_file
from werkzeug.utils import secure_filename
from flask import request, redirect, session
from flask_sqlalchemy import SQLAlchemy
from service import blogopen
from PIL import ImageDraw, Image, ImageFont
import sqlite3
import datetime
import os

from models import *
from utils.datasets import *
from utils.utils import *

import pandas as pd
from datetime import datetime


app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///loginDB.db'
app.config['SECRET_KEY'] = 'GYU'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

fontpath = 'data/NanumBarunGothic.ttf'
font = ImageFont.truetype(fontpath, 10)


class Name():
    def __init__(self, name):
        self.name = name

    def get_name(self):
        return self.name


name = Name("None")


@app.errorhandler(404)
def page_not_found(error):
    app.logger.error(error)
    return render_template('page_not_found.html'), 404


class User(db.Model):
    """Create user table"""
    __table_name__ = 'user'

    username = db.Column(db.String(80), primary_key=True)
    password = db.Column(db.String(80))
    email = db.Column(db.String(50), unique=True)
    age = db.Column(db.String(80))
    sex = db.Column(db.String(80))
    act = db.Column(db.String(80))

    def __init__(self, username, password, email, age, sex,act):
        self.username = username
        self.password = password
        self.email = email
        self.age = age
        self.sex = sex
        self.act = act


class User_food(db.Model):
    """Create user table"""
    __table_name__ = 'user_food'
    column_not_exist_in_db = db.Column(db.Integer, primary_key=True)
    username = db.Column('username', db.String(80), db.ForeignKey('user.username'))
    date = db.Column('날짜', db.DateTime, default=datetime.utcnow())
    food = db.Column('FOOD_LABEL', db.String(80))
    a1 = db.Column('단백질', db.Float, nullable=False)
    a2 = db.Column('탄수화물', db.Float, nullable=False)
    a3 = db.Column('지방', db.Float, nullable=False)
    a4 = db.Column('철분', db.Float, nullable=False)
    a5 = db.Column('오메가3', db.Float, nullable=False)
    a6 = db.Column('칼슘', db.Float, nullable=False)
    a7 = db.Column('비타민D', db.Float, nullable=False)
    a8 = db.Column('아연', db.Float, nullable=False)
    a9 = db.Column('비타민B12', db.Float, nullable=False)

    def __init__(self, username, date, food, a1,a2,a3,a4,a5,a6,a7,a8,a9):
        self.username = username
        self.date = date
        self.food = food
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4
        self.a5 = a5
        self.a6 = a6
        self.a7 = a7
        self.a8 = a8
        self.a9 = a9


# @app.route('/homepage', methods=['GET', 'POST'])
# def home():
#     if not session.get('logged_in'):
#         return render_template('login/index.html')
#     else:
#         if request.method == 'POST':
#             username = request.form['username']
#             return render_template('login/index.html', data=blogopen(username))
#         return render_template('login/index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login form"""
    if request.method == 'POST':
        global name
        name = request.form['username']
        passw = request.form['password']
        try:
            data = User.query.filter_by(username=name, password=passw).first()
            if data is not None:
                session['logged_in'] = True
                session['username'] = name
                return redirect(url_for('home'))
            else:
                return 'hi'
        except:
            return render_template('index.html', user=request.form['username']+"님 반갑습니다.")

    else:
        return render_template('login/login2.html')


@app.route('/register/', methods=['GET', 'POST'])
def register():
    """Register Form"""

    if request.method == 'POST':
        new_user = User(username=request.form['username'], password=request.form['password'],
                        email=request.form['email'], age=request.form['age'],
                        sex=request.form['sex'], act=request.form['act'])
        db.session.add(new_user)
        db.session.commit()
        return render_template('login/login2.html')
    return render_template('login/register2.html')


@app.route('/logout')
def logout():
    """Logout Form"""
    session['logged_in'] = False
    print("hi")
    session.pop('username', None)
    return redirect(url_for('home'))


@app.route('/')
def home_page():
    return render_template('login/register2.html')


@app.route('/upload')
def upload_page():
    session['username'] = session.get('username')
    return render_template('upload.html')


@app.route('/fileUpload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        global name
        print(name)
        f = request.files['file']
        print(secure_filename(f.filename))
        f.save('./uploads/' + secure_filename(f.filename))
        a = yolo_predict('./uploads/' + secure_filename(f.filename))

        con = sqlite3.connect('food_label.db')
        cur = con.cursor()
        a = list(set(a))
        print("a의 값 {0}".format(a))
        food = [_.strip() for _ in a]

        for i in food:
            cur.execute("SELECT * FROM food_label where food_label.FOOD_LABEL=='{}'".format(i))
        rows = cur.fetchall()
        cur.close()
        con.close()

        for row in rows:
            new_food = User_food(username=name, date=datetime.utcnow(),
                                 food=row[0], a1=row[1],a2=row[2],a3=row[3],a4=row[4],
                                 a5=row[5],a6=row[6],a7=row[7],a8=row[8],a9=row[9],)
            db.session.add(new_food)
            db.session.commit()

        user = User.query.filter_by(username=name).first()
        print(user)


        # con2 = sqlite3.connect('promote.db')
        # cur2 = con2.cursor()
        # cur2.execute("SELECT * FROM standard where standard.sex=='{}' and standard.age == '{'".format(sex, age))
        # row = cur.fetchall()

        # rows = cur.fetchall()
        # print(rows)
        # for row in rows:
        #     print(row)
        # cols = [column[0] for column in cur.description]
        # data_df = pd.DataFrame.from_records(data=rows, columns=cols)
        # print(data_df)

    #     sql = "select * from food_label where FOOD_LABEL not in ({seq})".format(
    # seq=','.join(['?']*len(a)))
    #     cur.execute(sql, a)
    #     print(info)
    # new_user = User_food(username=request.form['username'], date=datetime.date)
    # db.session.add(new_user)
    # db.session.commit()
        return render_template('visualize.html', sfile='./output/' + secure_filename(f.filename), label=a)
    else:
        return render_template('page_not_found.html')


@app.route('/downfile')
def down_page():
    files = os.listdir("./uploads")
    return render_template('filedown.html', files=files)


@app.route('/fileDown', methods=['GET', 'POST'])
def down_file():
    if request.method == 'POST':
        sw = 0
        files = os.listdir("./uploads")
        for x in files:
            if (x == request.form['file']):
                sw = 1
                path = "./uploads/"
                return send_file(path + request.form['file'],
                                 attachment_filename=request.form['file'],
                                 as_attachment=True)
        return render_template('page_not_found.html')
    else:
        return render_template('page_not_found.html')


@app.route('/predict', methods=['GET', 'POST'])
def yolo_predict(image_name = None):

    cfg = check_file('data/yolov3-spp31.cfg')
    names = check_file('data/classes.names')
    imgsz = 512
    a=[]
    with torch.no_grad():
        out, source, weights, view_img, save_txt, save_img, augment = './output/', image_name, 'data/best.pt', False, False, True, True
        device = torch_utils.select_device(device='cpu')
        print(check_file(source))

        global model
        model = Darknet(cfg, imgsz)
        model.load_state_dict(torch.load(weights, map_location=device)['model'])
        model.to(device).eval()

        vid_path, vid_writer = None, None
        save_img = True
        dataset = LoadImages(source, img_size=imgsz)

        names = load_classes(names)
        colors = [[random.randint(0, 255) for _ in range(3)] for _ in range(len(names))]

        t0 = time.time()
        img = torch.zeros((1, 3, imgsz, imgsz), device=device)  # init img
        _ = model(img.float()) if device.type != 'cpu' else None  # run once

        for path, img, im0s, vid_cap in dataset:
            img = torch.from_numpy(img).to(device)
            img = img.float()  # uint8 to fp16/32
            img /= 255.0
            if img.ndimension() == 3:
                img = img.unsqueeze(0)

            t1 = torch_utils.time_synchronized()
            pred = model(img, augment=augment)[0]
            t2 = torch_utils.time_synchronized()
            pred = non_max_suppression(pred, 0.15, 0.6, multi_label=False, classes=None, agnostic=False)

            for i, det in enumerate(pred):  # detections for image i

                p, s, im0 = path, '', im0s
                save_path = str(Path(out) / Path(p).name)
                s += '%gx%g ' % img.shape[2:]  # print string
                gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  #  normalization gain whwh
                if det is not None and len(det):
                    # Rescale boxes from imgsz to im0 size
                    det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                    # Print results
                    for c in det[:, -1].unique():
                        n = (det[:, -1] == c).sum()  # detections per class
                        s += '%g %ss, ' % (n, names[int(c)])  # add to string

                    # Write results
                    for *xyxy, conf, cls in reversed(det):
                        if save_txt:  # Write to file
                            xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                            with open(save_path[:save_path.rfind('.')] + '.txt', 'a') as file:
                                file.write(('%g ' * 5 + '\n') % (cls, *xywh))  # label format


                        label = '%s %.2f' % (names[int(cls)], conf)
                        a.append(names[int(cls)])
                        plot_one_box(xyxy, im0, label=label, color=colors[int(cls)])

                            # output label
                        c1, c2 = (int(xyxy[0]), int(xyxy[1])), (int(xyxy[2]), int(xyxy[3]))
                        img_pil = Image.fromarray(im0)
                        draw = ImageDraw.Draw(img_pil)
                        draw.text((c1[0], c1[1] - 10), label, font=font, fill=(255, 255, 255))
                        im0 = np.array(img_pil)

                # Print time (inference + NMS)
                print('%sDone. (%.3fs)' % (s, t2 - t1))

                # Save results (image with detections)
                if save_img:
                    if dataset.mode == 'images':
                        cv2.imwrite(save_path, im0)
    return a
@app.route("/result")
def result():
    return render_template("result.html")

@app.route("/result_data", methods=['GET','POST'])
def result_data():
    if request.method=='GET':
        result_name = request.form['result_name']
        return "{}님 환영합니다.".format(result_name)
    else:
        result_name = request.form['result_name']
        return "{}님 환영합니다.".format(result_name)

@app.route("/index")
def index_home():
    return render_template("index.html")

if __name__ == '__main__':
    db.create_all()
    app.secret_key = 'super secret key'
    app.run(debug=True)
