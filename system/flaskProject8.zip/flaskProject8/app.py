from flask import Flask, url_for, render_template, send_file
from werkzeug.utils import secure_filename
from flask import request, redirect, session
from flask_sqlalchemy import SQLAlchemy
from service import blogopen
from PIL import ImageDraw, Image, ImageFont
import sqlite3
import datetime
import os


from models import *
from utils.datasets import *
from utils.utils import *

import pandas as pd

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///loginDB.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

fontpath = 'data/NanumBarunGothic.ttf'
font = ImageFont.truetype(fontpath, 10)

@app.errorhandler(404)
def page_not_found(error):
    app.logger.error(error)
    return render_template('page_not_found.html'), 404

class food_label(db.Model):
    __tablename__ = 'food_label'
    FOOD_LABEL = db.Column(db.Integer, primary_key=True)
    a1 = db.Column(db.Float,  nullable=False)
    a2 = db.Column(db.Float,  nullable=False)
    a3 = db.Column(db.Float, nullable=False)
    a4 = db.Column(db.Float, nullable=False)
    a5 = db.Column(db.Float, nullable=False)
    a6 = db.Column(db.Float, nullable=False)
    a7 = db.Column(db.Float, nullable=False)
    a8 = db.Column(db.Float, nullable=False)
    a9 = db.Column(db.Float, nullable=False)
    a10 = db.Column(db.Float, nullable=False)

    def __init__(self,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10):
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4
        self.a5 = a5
        self.a6 = a6
        self.a7 = a7
        self.a8 = a8
        self.a9 = a9
        self.a10 = a10

class User(db.Model):
    """Create user table"""
    __table_name__ = 'user'

    username = db.Column(db.String(80), unique=True,primary_key=True)
    age = db.Column(db.Integer)
    sex = db.Column(db.String(80))

    def __init__(self, username, age, sex):
        self.username = username
        self.age = age
        self.sex = sex

class User_food(db.Model):
    """Create user table"""
    __table_name__ = 'user_food'

    username = db.Column(db.String(80), primary_key=True)
    date = db.Column(db.String(80))
    times = db.Column(db.String(80))
    a1 = db.Column(db.Float, nullable=False)
    a2 = db.Column(db.Float, nullable=False)
    a3 = db.Column(db.Float, nullable=False)
    a4 = db.Column(db.Float, nullable=False)
    a5 = db.Column(db.Float, nullable=False)
    a6 = db.Column(db.Float, nullable=False)
    a7 = db.Column(db.Float, nullable=False)
    a8 = db.Column(db.Float, nullable=False)
    a9 = db.Column(db.Float, nullable=False)
    a10 = db.Column(db.Float, nullable=False)

    def __init__(self, username, date, times, a1,a2,a3,a4,a5,a6,a7,a8,a9,a10):
        self.username = username
        self.date = date
        self.times = times
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4
        self.a5 = a5
        self.a6 = a6
        self.a7 = a7
        self.a8 = a8
        self.a9 = a9
        self.a10 = a10


@app.route('/a', methods=['GET', 'POST'])
def home():
    if not session.get('logged_in'):
        return render_template('login/index.html')
    else:
        if request.method == 'POST':
            username = request.form['username']
            return render_template('login/index.html', data=blogopen(username))
        return render_template('login/index.html')


@app.route('/input/', methods=['GET', 'POST'])
def register():
    """Register Form"""
    if request.method == 'GET':
        return render_template('login/register.html')
    elif request.method == 'POST':
        new_user = User(username=request.form['username'], age=request.form['age'], sex=request.form['sex'])
        db.session.add(new_user)
        db.session.commit()
        return render_template('home.html')


@app.route('/logout')
def logout():
    """Logout Form"""
    session['logged_in'] = False
    return redirect(url_for('home'))

# @app.route('/')
# def s():
#     aaaaa = yolo_predict('3_323.jpg')
#     print(aaaaa)
#     return "hello"


@app.route('/', methods=['GET', 'POST'])
def home_page():
    return render_template('home.html')


@app.route('/upload')
def upload_page():
    return render_template('upload.html')


@app.route('/fileUpload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        f = request.files['file']
        print(secure_filename(f.filename))
        f.save('./uploads/' + secure_filename(f.filename))
        a = yolo_predict('./uploads/' + secure_filename(f.filename))

        con = sqlite3.connect('food_label.db')
        cur = con.cursor()
        a = list(set(a))
        food = [_.strip() for _ in a]

        for i in food:
            cur.execute("select * from food_label where FOOD_LABEL=:who", {"who": i})
        rows = cur.fetchall()
        cols = [column[0] for column in cur.description]
        data_df = pd.DataFrame.from_records(data=rows, columns=cols)
        print(data_df)

    #     sql = "select * from food_label where FOOD_LABEL not in ({seq})".format(
    # seq=','.join(['?']*len(a)))
    #     cur.execute(sql, a)
    #     info = cur.fetchall()
    #     print(info)


        # new_user = User_food(username=request.form['username'], date=datetime.date, times="아침")
        # db.session.add(new_user)
        # db.session.commit()
        print('./output/' + secure_filename(f.filename))
        return render_template('visualize.html', sfile= './output/' + secure_filename(f.filename), label = a, info = info)
    else:
        return render_template('page_not_found.html')

@app.route('/uploading', methods=['GET', 'POST'])
def uploading():
    if request.method == 'POST':
        f = request.files['file']
        f.save('./uploads/' + secure_filename(f.filename))
        return render_template('check.html')
    else:
        return render_template('page_not_found.html')

@app.route('/downfile')
def down_page():
    files = os.listdir("./uploads")
    return render_template('filedown.html', files=files)


@app.route('/fileDown', methods=['GET', 'POST'])
def down_file():
    if request.method == 'POST':
        sw = 0
        files = os.listdir("./uploads")
        for x in files:
            if (x == request.form['file']):
                sw = 1
                path = "./uploads/"
                return send_file(path + request.form['file'],
                                 attachment_filename=request.form['file'],
                                 as_attachment=True)
        return render_template('page_not_found.html')
    else:
        return render_template('page_not_found.html')

@app.route('/predict', methods=['GET', 'POST'])
def yolo_predict(image_name = None):

    cfg = check_file('data/yolov3-spp31.cfg')
    names = check_file('data/classes.names')
    imgsz = 512
    a=[]
    with torch.no_grad():
        out, source, weights, view_img, save_txt, save_img, augment = './output/', image_name, 'data/best.pt', False, False, True, True
        device = torch_utils.select_device(device='cpu')
        print(check_file(source))

        global model
        model = Darknet(cfg, imgsz)
        model.load_state_dict(torch.load(weights, map_location=device)['model'])
        model.to(device).eval()

        vid_path, vid_writer = None, None
        save_img = True
        dataset = LoadImages(source, img_size=imgsz)

        names = load_classes(names)
        colors = [[random.randint(0, 255) for _ in range(3)] for _ in range(len(names))]

        t0 = time.time()
        img = torch.zeros((1, 3, imgsz, imgsz), device=device)  # init img
        _ = model(img.float()) if device.type != 'cpu' else None  # run once

        for path, img, im0s, vid_cap in dataset:
            img = torch.from_numpy(img).to(device)
            img = img.float()  # uint8 to fp16/32
            img /= 255.0
            if img.ndimension() == 3:
                img = img.unsqueeze(0)

            t1 = torch_utils.time_synchronized()
            pred = model(img, augment=augment)[0]
            t2 = torch_utils.time_synchronized()
            pred = non_max_suppression(pred, 0.1, 0.6, multi_label=False, classes=None, agnostic=False)

            for i, det in enumerate(pred):  # detections for image i

                p, s, im0 = path, '', im0s
                save_path = str(Path(out) / Path(p).name)
                s += '%gx%g ' % img.shape[2:]  # print string
                gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  #  normalization gain whwh
                if det is not None and len(det):
                    # Rescale boxes from imgsz to im0 size
                    det[:, :4] = scale_coords(img.shape[2:], det[:, :4], im0.shape).round()

                    # Print results
                    for c in det[:, -1].unique():
                        n = (det[:, -1] == c).sum()  # detections per class
                        s += '%g %ss, ' % (n, names[int(c)])  # add to string

                    # Write results
                    for *xyxy, conf, cls in reversed(det):
                        if save_txt:  # Write to file
                            xywh = (xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                            with open(save_path[:save_path.rfind('.')] + '.txt', 'a') as file:
                                file.write(('%g ' * 5 + '\n') % (cls, *xywh))  # label format


                        label = '%s %.2f' % (names[int(cls)], conf)
                        a.append(names[int(cls)])
                        plot_one_box(xyxy, im0, label=label, color=colors[int(cls)])

                            # output label
                        c1, c2 = (int(xyxy[0]), int(xyxy[1])), (int(xyxy[2]), int(xyxy[3]))
                        img_pil = Image.fromarray(im0)
                        draw = ImageDraw.Draw(img_pil)
                        draw.text((c1[0], c1[1] - 10), label, font=font, fill=(255, 255, 255))
                        im0 = np.array(img_pil)

                # Print time (inference + NMS)
                print('%sDone. (%.3fs)' % (s, t2 - t1))

                # Save results (image with detections)
                if save_img:
                    if dataset.mode == 'images':
                        cv2.imwrite(save_path, im0)
    return a


if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
